`timescale 1ns / 1ps

module CPU_tb;

    // Inputs
    reg clk;
    reg reset;

    // Outputs
    wire [31:0] instruction;
    wire [31:0] pc;

    // Instruction memory 
    wire [31:0] write_data;
    wire [4:0] write_register;
    

    // Instantiate the Unit Under Test (UUT)
    CPU uut (
        .clk(clk), 
        .reset(reset),
        .instruction(instruction),
        .pc(pc),
        .write_data(write_data),
        .write_register(write_register)
    );

    initial begin
        // Initialize Inputs
        clk = 0;
        reset = 1;
        @ (posedge clk);

        // Wait for global reset to finish
        #50;
        reset = 0;

        // Add stimulus here
        #50;
    end

    always #100 clk = ~clk;

endmodule
