`timescale 1ns/1ps

module MEM2(clk, rt, address, write_data, mem_write, mem_read, dm_op, rd_mem2_wb, reg_write_mem2_wb, data_wb, read_data);

    input clk;
    input [4:0] rt;
    input [11:0] address;
    input [31:0] write_data;
    input mem_write;
    input mem_read;
    input [1:0] dm_op;
    input [4:0] rd_mem2_wb;
    input reg_write_mem2_wb;
    input [31:0] data_wb;
    output [31:0] read_data;

    wire forward_a;
    wire [31:0] write_data_forward;

    FUMEM2 forwarding_unit(.rt(rt), .rd_mem2_wb(rd_mem2_wb), .reg_write_mem2_wb(reg_write_mem2_wb), .forward_a(forward_a));

    Mux2To1 #(.n(32)) address_mux(.out(write_data_forward), .inA(write_data), .inB(data_wb), .sel(forward_a));

    DM data_memory(.Clk(clk), .Address(address), .WriteData(write_data_forward), .MemWrite(mem_write), .MemRead(mem_read), .DMOp(dm_op), .ReadData(read_data));

endmodule
