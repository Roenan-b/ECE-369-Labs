# Exercise 3
#Students:
# Cieran Wong 33%
# Nick Brown 33%
# Darryl Mercado 33%
# Max Score: 12 points
.data	
list1:		.word		3, 9, 1, 2, 6, 3, -4, -7, -8, 4, -2,  8, 7, 6
.text 		# list1 is an array of integers storing the given sequence of values	 
.globl	tomato
tomato: 
addi	$sp, $sp, -8       
addi	$t0, $a0, -1       
sw  	$t0, 0($sp)        
sw  	$ra, 4($sp)        
bne 	$a0, $zero, orange   
li  	$v0, 0             
addi	$sp, $sp, 8        
jr 	$ra                  
orange:   
move  $a0, $t0            
jal   	tomato 
lw    	$t0, 0($sp)  
sll	$t1, $t0, 2  
add   	$t1, $t1, $a1     
lw    	$t2, 0($t1)       
add   	$v0, $v0, $t2     
lw    	$ra, 4($sp)                
addi 	$sp, $sp, 8        
jr 	$ra                  
# main function starts here                                            						
.globl main
main:	
    addi	$sp, $sp, -4	# Make space on stack
	sw	$ra, 0($sp)	# Save return address
	la	$a1, list1	# a1 has the base address pointing to the first 
# element of the “list1” array declared in .data section above
	li	$a0, 9		# loads the immediate value into the destination register
	jal	tomato	
return:	
li	$v0, 0			# Return value
	lw	$ra, 0($sp)		# Restore return address
	addi	$sp, $sp, 4		# Restore stack pointer
	jr 	$ra			# Return
# Step through this code in your simulator and monitor the register values. 
# What does the tomato function do?   
# Write your answer HERE_ _ _ _ _ _ _ _ _ 
# The tomato function is a recursive function that calculates the sum of the elements in the list1 array.
# It takes two arguments, the first argument is the index of the element in the list1 array, and the second argument is the base address of the list1 array.
# The function first decrements the index by 1 and stores it in the stack. It finds the address (line 19) and stores that in the slot below the index within the stack. It then checks if the index is 0, if it is, it exits the recursive call and proceeds to line 19. If the index is not equal to 0, it continues calling the loop again, decrementing the index and storing the value within the stack alongside the return address. From line 19, it loads the value at the address of the index in the list1 array and adds it to the return value. It then returns the sum of the elements in the list1 array. This is going through the stack in reverse order.    
# t0 values: 8, 7, 6, 5, 4, 3, 2, 1, 0, -1
# a0 values: 9, 8, 7, 6, 5, 4, 3, 2, 1, 0
# v0 values: 0, 3, 12, 13, 15, 21, 24, 20, 13, 5
