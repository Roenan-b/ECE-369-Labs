`timescale 1ns/1ps

module WB(pc_in, read_data, alu_output, mem_to_reg, write_data);

    input [31:0] pc_in;
    input [31:0] read_data;
    input [31:0] alu_output;
    input [1:0] mem_to_reg;
    output [31:0] write_data;

    Mux3To1 #(.n(32)) mux(.out(write_data), .inA(read_data), .inB(alu_output), .inC(pc_in), .sel(mem_to_reg));

endmodule
