`timescale 1ns/1ps

module MEM1MEM2 (clk, reset, pc_in, rd_in, rt_in, alu_output_in, address_in, write_data_in, mem_write_in, mem_read_in, dm_op_in, mem_to_reg_in, reg_write_in, pc_out, rd_out, rt_out, alu_output_out, address_out, write_data_out, mem_write_out, mem_read_out, dm_op_out, mem_to_reg_out, reg_write_out);

    input clk;
    input reset;
    input [31:0] pc_in;
    input [4:0] rd_in;
    input [4:0] rt_in;
    input [31:0] alu_output_in;
    input [11:0] address_in;
    input [31:0] write_data_in;
    input mem_write_in;
    input mem_read_in;
    input [1:0] dm_op_in;
    input [1:0] mem_to_reg_in;
    input reg_write_in;
    output reg [31:0] pc_out;
    output reg [4:0] rd_out;
    output reg [4:0] rt_out;
    output reg [31:0] alu_output_out;
    output reg [11:0] address_out;
    output reg [31:0] write_data_out;
    output reg mem_write_out;
    output reg mem_read_out;
    output reg [1:0] dm_op_out;
    output reg [1:0] mem_to_reg_out;
    output reg reg_write_out;

    always @(posedge clk) begin
        if (reset) begin
            pc_out <= 0;
            rd_out <= 5'b0;
            rt_out <= 5'b0;
            alu_output_out <= 32'b0;
            address_out <= 12'b0;
            write_data_out <= 32'b0;
            mem_write_out <= 1'b0;
            mem_read_out <= 1'b0;
            dm_op_out <= 2'b0;
            mem_to_reg_out <= 2'b0;
            reg_write_out <= 1'b0;
        end else begin
            pc_out <= pc_in;
            rd_out <= rd_in;
            rt_out <= rt_in;
            alu_output_out <= alu_output_in;
            address_out <= address_in;
            write_data_out <= write_data_in;
            mem_write_out <= mem_write_in;
            mem_read_out <= mem_read_in;
            dm_op_out <= dm_op_in;
            mem_to_reg_out <= mem_to_reg_in;
            reg_write_out <= reg_write_in;
        end
    end

endmodule
