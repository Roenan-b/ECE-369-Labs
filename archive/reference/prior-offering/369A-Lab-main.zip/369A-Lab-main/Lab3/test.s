    .data
frame:    .word 0, 0, 1, 2, 0, 0, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0
window:   .word 1, 2, 3, 4
min_sad:  .word 1000000   # Initial large value for min_sad
min_x:    .word 0
min_y:    .word 0
dimensions_info: .word 4, 4, 2, 2

    .text
    .globl main

    frame_loop:
    # Check if run_count == 0
    beq  $a2, $zero, end_frame_loop

    # Loop for movement == 1
    li   $t0, 1
    bne  $a3, $t0, check_movement_2

    # For movement == 1 (nested loops)
    li   $t1, 0                # i = 0
frame_loop_outer_1:
    bge  $t1, $a0, next_movement_2  # if i >= sad_size_x, exit loop

    li   $t2, 0                # j = 0
frame_loop_inner_1:
    bge  $t2, $a1, inc_i_1     # if j >= sad_size_y, exit inner loop

    # Call window_loop
    move $a0, $t1              # Pass i
    move $a1, $t2              # Pass j
    jal  window_loop

    addi $t2, $t2, 1           # j++
    j    frame_loop_inner_1

inc_i_1:
    addi $t1, $t1, 1           # i++
    j    frame_loop_outer_1

check_movement_2:
    # Similar structure for movement 2, 3, and 4
    # Adjust looping accordingly

next_movement_2:
    # Increment movement
    addi $a3, $a3, 1           # movement = (movement % 4) + 1
    b    frame_loop

window_loop:
    # Save registers for i, j, and min_sad
    addi $sp, $sp, -12
    sw   $a0, 0($sp)
    sw   $a1, 4($sp)
    sw   $a2, 8($sp)

    # Loop over x and y for window array
    li   $t0, 0                # x = 0
window_outer:
    bge  $t0, $a2, end_window_outer  # if x >= window_x, exit outer loop

    li   $t1, 0                # y = 0
window_inner:
    bge  $t1, $a3, end_window_inner  # if y >= window_y, exit inner loop

    # Calculate indices in frame and window
    # frame_index = (i + x) * frame_y + (j + y)
    # window_index = x * window_y + y
    lw   $t2, 0($sp)           # i
    add  $t2, $t2, $t0         # i + x
    mul  $t2, $t2, $a1         # (i + x) * frame_y
    lw   $t3, 4($sp)           # j
    add  $t3, $t3, $t1         # j + y
    add  $t2, $t2, $t3         # frame_index

    mul  $t4, $t0, $a3         # x * window_y
    add  $t4, $t4, $t1         # window_index

    # Load frame and window values
    la   $t5, frame            # Load frame base address
    la   $t6, window           # Load window base address
    lw   $t5, 0($t5)           # Load frame[frame_index]
    lw   $t6, 0($t6)           # Load window[window_index]

    # Calculate sad_value += abs(frame - window)
    sub  $t7, $t5, $t6         # frame - window
    abs  $t7, $t7              # abs(frame - window)
    add  $a2, $a2, $t7         # sad_value += abs(frame - window)

    # Compare and update min_sad
    lw   $t8, min_sad
    blt  $a2, $t8, update_min_sad

update_min_sad:
    sw   $a2, min_sad          # Update min_sad
    lw   $t0, min_x
    sw   $t0, min_x            # Update min_x, min_y
    lw   $t1, min_y
    sw   $t1, min_y

    addi $t1, $t1, 1           # y++
    j    window_inner

end_window_inner:
    addi $t0, $t0, 1           # x++
    j    window_outer

frame_loop:
    # Base case: check if run_count == 0
    beq  $a2, $zero, end_frame_loop

    # Loop for movement == 1
    li   $t0, 1
    bne  $a3, $t0, check_movement_2

    # Movement 1: i (rows) increases, j (cols) increases
    li   $t1, 0                # i = 0
frame_loop_outer_1:
    bge  $t1, $a0, next_movement_2  # if i >= sad_size_x, exit loop

    li   $t2, 0                # j = 0
frame_loop_inner_1:
    bge  $t2, $a1, inc_i_1     # if j >= sad_size_y, exit inner loop

    # Call window_loop with i, j
    move $a0, $t1              # i
    move $a1, $t2              # j
    jal  window_loop

    addi $t2, $t2, 1           # j++
    j    frame_loop_inner_1

inc_i_1:
    addi $t1, $t1, 1           # i++
    j    frame_loop_outer_1

# Movement 2: j increases, i increases (flip row/col loop order)
check_movement_2:
    li   $t0, 2
    bne  $a3, $t0, check_movement_3

    li   $t2, 0                # j = 0
frame_loop_outer_2:
    bge  $t2, $a1, next_movement_3  # if j >= sad_size_y, exit loop

    li   $t1, 0                # i = 0
frame_loop_inner_2:
    bge  $t1, $a0, inc_j_2     # if i >= sad_size_x, exit inner loop

    # Call window_loop with i, j
    move $a0, $t1              # i
    move $a1, $t2              # j
    jal  window_loop

    addi $t1, $t1, 1           # i++
    j    frame_loop_inner_2

inc_j_2:
    addi $t2, $t2, 1           # j++
    j    frame_loop_outer_2

# Movement 3: i decreases, j decreases (reverse both directions)
check_movement_3:
    li   $t0, 3
    bne  $a3, $t0, check_movement_4

    li   $t1, 0                # Start from sad_size_x - 1
    sub  $t1, $a0, 1           # i = sad_size_x - 1
frame_loop_outer_3:
    blt  $t1, $zero, next_movement_4  # if i < 0, exit loop

    li   $t2, 0
    sub  $t2, $a1, 1           # j = sad_size_y - 1
frame_loop_inner_3:
    blt  $t2, $zero, dec_i_3     # if j < 0, exit inner loop

    # Call window_loop with i, j
    move $a0, $t1              # i
    move $a1, $t2              # j
    jal  window_loop

    addi $t2, $t2, -1          # j--
    j    frame_loop_inner_3

dec_i_3:
    addi $t1, $t1, -1          # i--
    j    frame_loop_outer_3

# Movement 4: j decreases, i decreases
check_movement_4:
    li   $t0, 4
    bne  $a3, $t0, end_frame_loop

    li   $t2, 0
    sub  $t2, $a1, 1           # j = sad_size_y - 1
frame_loop_outer_4:
    blt  $t2, $zero, next_movement_1  # if j < 0, exit loop

    li   $t1, 0
    sub  $t1, $a0, 1           # i = sad_size_x - 1
frame_loop_inner_4:
    blt  $t1, $zero, dec_j_4     # if i < 0, exit inner loop

    # Call window_loop with i, j
    move $a0, $t1              # i
    move $a1, $t2              # j
    jal  window_loop

    addi $t1, $t1, -1          # i--
    j    frame_loop_inner_4

dec_j_4:
    addi $t2, $t2, -1          # j--
    j    frame_loop_outer_4

next_movement_1:
    # Restore movement to 1 and recurse
    li   $a3, 1                # movement = 1
    addi $a2, $a2, -1          # run_count--

    # Recursive call to frame_loop
    jal  frame_loop

end_frame_loop:
    jr   $ra                   # Return to caller

main:
    # Load the dimensions_info array values into registers
    la   $t0, dimensions_info  # Load address of dimensions_info
    lw   $a0, 0($t0)           # frame_x = dimensions_info[0]
    lw   $a1, 4($t0)           # frame_y = dimensions_info[1]
    lw   $a2, 8($t0)           # window_x = dimensions_info[2]
    lw   $a3, 12($t0)          # window_y = dimensions_info[3]

    # Calculate sad_size_x and sad_size_y
    sub  $t1, $a0, $a2         # sad_size_x = frame_x - window_x
    addi $t1, $t1, 1           # sad_size_x += 1
    sub  $t2, $a1, $a3         # sad_size_y = frame_y - window_y
    addi $t2, $t2, 1           # sad_size_y += 1

    # run_count = sad_size_x * sad_size_y
    mul  $t3, $t1, $t2         # run_count = sad_size_x * sad_size_y

    # Initialize variables
    li   $t4, 1                # movement = 1
    la   $t5, min_sad          # Load address of min_sad
    la   $t6, min_x            # Load address of min_x
    la   $t7, min_y            # Load address of min_y

    # Call frame_loop function
    move $a0, $t1              # sad_size_x
    move $a1, $t2              # sad_size_y
    move $a2, $t3              # run_count
    jal  frame_loop            # Jump to frame_loop