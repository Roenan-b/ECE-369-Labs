`timescale 1ns / 1ps

module ShiftLeft2 #(parameter n = 32)(inA, Shift_out);

    input [n-1:0] inA;
    output [n-1:0] Shift_out;
    
    assign Shift_out = inA << 2;
endmodule