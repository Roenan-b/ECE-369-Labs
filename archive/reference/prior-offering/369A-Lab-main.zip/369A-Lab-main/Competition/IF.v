`timescale 1ns/1ps

module IF(clk, reset, pc_in, pc_src, pc_write, jump_op, jr_op, jump_target, branch_target, jump_register, instruction_out, pc_out);

    input clk;
    input reset;
    input [31:0] pc_in;
    input pc_src;
    input pc_write;
    input jump_op;
    input jr_op;
    input [31:0] jump_target;
    input [31:0] branch_target;
    input [31:0] jump_register;
    output [31:0] instruction_out;
    output wire [31:0] pc_out;

    wire [31:0] jump_pc, jr_pc, branch_pc, pc_curr;
    
    Mux2To1 #(.n(32)) mux2(.out(jump_pc), .inA(pc_in), .inB(jump_target), .sel(jump_op));

    Mux2To1 #(.n(32)) mux2(.out(jr_op), .inA(jump_pc), .inB(jump_register), .sel(jr_op));

    Mux2To1 #(.n(32)) mux2(.out(branch_pc), .inA(jr_op), .inB(branch_target), .sel(pc_src));
    
    PC pc(.Address(branch_pc), .PCResult(pc_curr), .Reset(reset), .Clk(clk), .PCWrite(pc_write));
    
    IM instruction_memory(.Address(pc_curr[31:2]), .Instruction(instruction_out));
    
    AddALU pc_adder(.inA(pc_curr), .inB(32'b00000000000000000000000000000100), .Add_out(pc_out));

endmodule
