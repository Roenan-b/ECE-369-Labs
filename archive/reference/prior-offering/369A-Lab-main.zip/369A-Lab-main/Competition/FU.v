`timescale 1ns/1ps

module FU(register_1, register_2, early_stage_reg_write, early_stage_register, later_stage_reg_write, later_stage_register, forward_a, forward_b);

    input [4:0] register_1;
    input [4:0] register_2;
    input early_stage_reg_write;
    input [4:0] early_stage_register;
    input later_stage_reg_write;
    input [4:0] later_stage_register;
    output reg [1:0] forward_a;
    output reg [1:0] forward_b;

    always @(*) begin

        forward_a <= 2'b00;
        forward_b <= 2'b00;
       
       // input 1 forwarding
       // earlier stage
        if ((early_stage_reg_write) && (early_stage_register != 0) && (early_stage_register == register_1)) begin
            forward_a <= 2'b10;
        end
        // later stage
        else if ((later_stage_reg_write) && (later_stage_register != 0) && (later_stage_register == register_1)) begin
            forward_a <= 2'b01;
        end

        // input 2 forwarding
       // earlier stage
        if ((early_stage_reg_write) && (early_stage_register != 0) && (early_stage_register == register_2)) begin
            forward_b <= 2'b01;
        end
        // later stage
        else if ((later_stage_reg_write) && (later_stage_register != 0) && (later_stage_register == register_2)) begin
            forward_b <= 2'b10;
        end
    end
endmodule