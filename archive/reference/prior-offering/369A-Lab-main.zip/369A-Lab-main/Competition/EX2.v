`timescale 1ns/1ps

module EX2(rt, rs, alu_input_1, alu_input_2, alu_control, rd_ex2_mem1, rd_mem2_wb, data_ex2_mem1, data_mem2_wb, reg_write_ex2_mem1, reg_write_mem2_wb, alu_output);

    input [4:0] rt;
    input [4:0] rs;
    input [31:0] alu_input_1;
    input [31:0] alu_input_2;
    input [4:0] alu_control;
    input [4:0] rd_ex2_mem1;
    input [4:0] rd_mem2_wb;
    input [31:0] data_ex2_mem1;
    input [31:0] data_mem2_wb;
    input reg_write_ex2_mem1;
    input reg_write_mem2_wb;
    output [31:0] alu_output;

    wire [31:0] forward_a_mux_out, forward_b_mux_out;
    wire [1:0] forward_a, forward_b;

    FU branch_forwarding(.register_1(rs), .register_2(rt), .early_stage_reg_write(reg_write_ex2_mem1), .early_stage_register(rd_ex2_mem1), .later_stage_reg_write(reg_write_mem2_wb), .later_stage_register(rd_mem2_wb), .forward_a(forward_a), .forward_b(forward_b));

    Mux3To1 #(.n(32)) forward_b_mux(.out(forward_b_mux_out), .inA(alu_input_2), .inB(data_ex2_mem1), .inC(data_mem2_wb), .sel(forward_b));

    Mux3To1 #(.n(32)) forward_a_mux(.out(forward_a_mux_out), .inA(alu_input_1), .inB(data_mem2_wb), .inC(data_ex2_mem1), .sel(forward_a));

    ALU32Bit alu(.ALUControl(alu_control), .A(forward_a_mux_out), .B(forward_b_mux_out), .ALUResult(alu_output));

endmodule