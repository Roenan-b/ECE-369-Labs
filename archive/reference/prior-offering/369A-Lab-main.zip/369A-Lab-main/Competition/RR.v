`timescale 1ns/1ps

module RR(clk, instruction, write_data, write_register, reg_write_in, pc_in, rd_ex2_mem1, reg_write_ex2_mem1, data_ex2_mem1, branch, branch_op, rd_out, rt_out, rs_out, imm_out, read_data_2, read_data_1, branch_target, pc_src);

    input clk;
    input [25:0] instruction;
    input [31:0] write_data;
    input [4:0] write_register;
    input reg_write_in;
    input [31:0] pc_in;
    input [4:0] rd_ex2_mem1;
    input reg_write_ex2_mem1;
    input [31:0] data_ex2_mem1;
    input branch;
    input [2:0] branch_op;
    output [4:0] rd_out;
    output [4:0] rt_out;
    output [4:0] rs_out;
    output wire [31:0] imm_out;
    output wire [31:0] read_data_2;
    output wire [31:0] read_data_1;
    output [31:0] branch_target;
    output pc_src;

    wire [4:0] rd = instruction[15:11];
    wire [4:0] rt = instruction[20:16];
    wire [4:0] rs = instruction[25:21];
    wire [15:0] imm = instruction[15:0];
    wire [31:0] shift_offset, alu_input_1, alu_input_2;
    wire [1:0] forward_a, forward_b;
    
    assign rd_out = rd;
    assign rt_out = rt;
    assign rs_out = rs;
    
    SignExtension sign_extend(.in(imm), .out(imm_out));

    RegisterFile registers(.Clk(clk), .ReadRegister1(rs), .ReadRegister2(rt), .WriteRegister(write_register), .WriteData(write_data), .RegWrite(reg_write_in), .ReadData1(read_data_1), .ReadData2(read_data_2));
  
    ShiftLeft2 #(.n(32)) shift_left_2(.inA(imm_out), .Shift_out(shift_offset));

    AddALU branch_add(.inA(pc_in), .inB(shift_offset), .Add_out(branch_target));

    FU branch_forwarding(.register_1(rs), .register_2(rt), .early_stage_reg_write(reg_write_ex2_mem1), .early_stage_register(rd_ex2_mem1), .later_stage_reg_write(reg_write_in), .later_stage_register(write_register), .forward_a(forward_a), .forward_b(forward_b));

    Mux3To1 #(.n(32)) mux1(.out(alu_input_2), .inA(read_data_2), .inB(data_ex2_mem1), .inC(write_data), .sel(forward_b));
    Mux3To1 #(.n(32)) mux2(.out(alu_input_1), .inA(read_data_1), .inB(write_data), .inC(data_ex2_mem1), .sel(forward_a));

    BranchALU branch_alu(.branch_op(branch_op), .branch(branch), .A(alu_input_1), .B(alu_input_2), .pc_src(pc_src));

endmodule