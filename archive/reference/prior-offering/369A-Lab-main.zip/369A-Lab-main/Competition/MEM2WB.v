`timescale 1ns/1ps

module MEM2WB (clk, reset, pc_in, rd_in, alu_output_in, read_data_in, mem_to_reg_in, reg_write_in, pc_out, rd_out, alu_output_out, read_data_out, mem_to_reg_out, reg_write_out);

    input clk;
    input reset;
    input [31:0] pc_in;
    input [4:0] rd_in;
    input [31:0] alu_output_in;
    input [31:0] read_data_in;
    input [1:0] mem_to_reg_in;
    input reg_write_in;
    output reg [31:0] pc_out;
    output reg [4:0] rd_out;
    output reg [31:0] alu_output_out;
    output reg [31:0] read_data_out;
    output reg [1:0] mem_to_reg_out;
    output reg reg_write_out;

    always @(posedge clk) begin
        if (reset) begin
            pc_out <= 0;
            rd_out <= 5'b0;
            alu_output_out <= 32'b0;
            read_data_out <= 32'b0;
            mem_to_reg_out <= 2'b0;
            reg_write_out <= 1'b0;
        end 
        else begin
            pc_out <= pc_in;
            rd_out <= rd_in;
            alu_output_out <= alu_output_in;
            read_data_out <= read_data_in;
            mem_to_reg_out <= mem_to_reg_in;
            reg_write_out <= reg_write_in;
        end
    end

endmodule
