`timescale 1ns / 1ps

module ALU32Bit(ALUControl, A, B, ALUResult);

	input [4:0] ALUControl;    
	input signed [31:0] A, B;

	output reg signed [31:0] ALUResult;
        
    /*
    Used 5'bxxxxx values
    5'b00000:  add
    5'b00001:  sub
    5'b00010:  and
    5'b00011:  or
    5'b00100:  nor
    5'b00101:  xor
    5'b00110:  sll (shift left logical)
    5'b00111:  srl (shift right logical)
    5'b01000:  slt (set on less than)
    5'b01001:  mul (multiply)
    5'b10000:  addi (add immediate)
    5'b10001:  andi (and immediate)
    5'b10010:  ori (or immediate)
    5'b10011:  xori (xor immediate)
    5'b11100:  slti

    Unused 5'bxxxxx values
    5'b01010:  Unused
    5'b01011   Unused
    5'b11110   Unused
    5'b01100   Unused
    5'b01101:  Unused
    5'b01110:  Unused
    5'b01111:  Unused
    5'b10100:  Unused
    5'b10101:  Unused
    5'b10110:  Unused
    5'b10111:  Unused
    5'b11000:  Unused
    5'b11001:  Unused
    5'b11010:  Unused
    5'b11011:  Unused
    5'b11101:  Unused
    5'b11111:  Unused
    */

    always @ (*) begin
        case (ALUControl)
            5'b00000: begin //add
                ALUResult = A + B;
            end
            5'b00001: begin //sub
                ALUResult = A - B;
            end
            5'b00010: begin //and
                ALUResult = A & B;
            end
            5'b00011: begin //or
                ALUResult = A | B;
            end
            5'b00100: begin //nor
                ALUResult = ~(A|B);
            end
            5'b00101: begin //xor
                ALUResult = A ^ B;
            end
            5'b00110: begin //sll
                ALUResult = A << B[10:6];
            end
            5'b00111: begin //srl
                ALUResult = A >> B[10:6];
            end
            5'b01000: begin //slt
                ALUResult = (A < B) ? 1 : 0;
            end
            5'b01001: begin //mul
                ALUResult = A * B;
            end
            5'b10000: begin //addi
                ALUResult = A + B;
            end
            5'b10001: begin //andi
                ALUResult = A & B;
            end
            5'b10010: begin //ori
                ALUResult = A | B;
            end
            5'b10011: begin //xori
                ALUResult = A ^ B;
            end
            5'b11100: begin //slti
                ALUResult = (A < B) ? 1 : 0;
            end
            default: begin
                ALUResult = 0;
            end
            endcase
    end
endmodule

