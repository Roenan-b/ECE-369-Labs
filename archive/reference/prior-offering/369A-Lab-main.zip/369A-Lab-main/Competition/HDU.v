`timescale 1ns/1ps

module HDU(op_code_id, rs_id, rt_id, rt_id_rr, rt_rr_ex1, rd_id_rr, mem_read_id_rr, mem_read_rr_ex1, if_id_write, pc_write, control_mux);

    input [5:0] op_code_id;
    input [4:0] rs_id;
    input [4:0] rt_id;
    input [4:0] rt_id_rr;
    input [4:0] rt_rr_ex1;
    input [4:0] rd_id_rr;
    input mem_read_id_rr;
    input mem_read_rr_ex1;
    output reg if_id_write;
    output reg pc_write;
    output reg control_mux;

    always @(*) begin
        
        if_id_write <= 1;
        pc_write <= 1;
        control_mux <= 0;

        // ID/EX Dependencies
        // if the instruction in this phase is any memory instruction and the address field is not being written to, it can bypass stall
        if ((mem_read_id_rr) & ((rt_id_rr == rs_id) | (rt_id_rr == rt_id)) 
            && !(((op_code_id == 6'b100011) || (op_code_id == 6'b100001) || (op_code_id == 6'b100000)
            || (op_code_id == 6'b101011) || (op_code_id == 6'b101001) || (op_code_id == 6'b101000)) 
            && ((rt_id_rr == rs_id) || (rd_id_rr == rs_id)))) begin
            if_id_write <= 0;  
            pc_write <= 0;  
            control_mux <= 1;
        end

        // ID/MEM Dependencies
        // if the instruction in this phase is any memory instruction it can bypass stall
        else if ((mem_read_rr_ex1) & ((rt_rr_ex1 == rs_id) | (rt_rr_ex1 == rt_id))
            && !((op_code_id == 6'b100011) || (op_code_id == 6'b100001) || (op_code_id == 6'b100000)
            || (op_code_id == 6'b101011) || (op_code_id == 6'b101001) || (op_code_id == 6'b101000))) begin
            if_id_write <= 0;  
            pc_write <= 0;  
            control_mux <= 1;
        end
    end
endmodule