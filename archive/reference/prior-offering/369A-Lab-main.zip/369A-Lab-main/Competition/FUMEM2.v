`timescale 1ns/1ps

module FUMEM2(rt, rd_mem2_wb, reg_write_mem2_wb, forward_a);

    input [4:0] rt;
    input [4:0] rd_mem2_wb;
    input reg_write_mem2_wb;
    output reg forward_a;

    always @(*) begin

        forward_a <= 0;
       
       // address
        if ((reg_write_mem2_wb) && (rd_mem2_wb != 0) && (rd_mem2_wb == rt)) begin
            forward_a <= 2'b1;
        end
        
    end
endmodule