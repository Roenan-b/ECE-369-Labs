`timescale 1ns / 1ps

module IM(Address, Instruction); 

    input [29:0] Address;

    output reg [31:0] Instruction; 

    reg [31:0] memory [0:1023];
    integer i;
    initial begin
        //$readmemh("instruction_memory.mem", memory);
        $readmemh("private_instruction_memory_lab6.mem", memory);
    end
    
    always @ (*) begin
        Instruction = memory[Address];
    end

endmodule
