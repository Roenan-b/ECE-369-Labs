`timescale 1ns / 1ps

module DM(Clk, Address, WriteData, MemWrite, MemRead, DMOp, ReadData);

    input Clk;
    input [11:0] Address;
    input [31:0] WriteData;
    input MemWrite; 
    input MemRead; 
    input [1:0] DMOp;     
    output reg [31:0] ReadData;

    reg [31:0] memory [0:1023];

    initial begin
        //$readmemh("data_memory.mem", memory);
        $readmemh("private_data_memory_lab6.mem", memory);
    end

    always @(negedge Clk) begin
        if (MemWrite) begin
            case (DMOp)
                2'b00: begin  // Store byte
                    memory[Address[11:2]][(Address[1:0] * 8) +: 8] <= WriteData[7:0];
                end
                2'b01: begin  // Store half-word
                    memory[Address[11:2]][(Address[1] * 16) +: 16] <= WriteData[15:0];
                end
                2'b11: begin  // Store word
                    memory[Address[11:2]] <= WriteData;
                end
                default: begin
                    // No operation
                end
            endcase
        end
    end

    always @(*) begin
        if (MemRead) begin
            case (DMOp)
                2'b00: begin  // Load byte (zero-extended)
                    ReadData = {24'b0, memory[Address[11:2]][(Address[1:0] * 8) +: 8]};
                end
                2'b01: begin  // Load half-word (zero-extended)
                    ReadData = {16'b0, memory[Address[11:2]][(Address[1] * 16) +: 16]};
                end
                2'b11: begin  // Load word
                    ReadData = memory[Address[11:2]];
                end
                default: begin
                    ReadData = 32'b0;
                end
            endcase
        end else begin
            ReadData = 32'b0;
        end
    end

endmodule