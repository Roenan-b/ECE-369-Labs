`timescale 1ns / 1ps

module Mux2To1 #(parameter n = 32) (out, inA, inB, sel);

    output reg [n-1:0] out;
    
    input [n-1:0] inA;
    input [n-1:0] inB;
    input sel;

    always@(*) begin
        if (sel) begin
            out <= inB;
        end
        else if (sel == 0) begin
            out <= inA;
        end
        else begin
            out <= inA;
        end
    end
endmodule
