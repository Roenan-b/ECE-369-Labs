`timescale 1ns/1ps

module EX1(reg_dst, rd_in, rt_in, alu_op, imm, read_data_2, read_data_1, alu_src, alu_sl, rd_out, alu_input_1, alu_input_2, alu_control);

    input [1:0] reg_dst;
    input [4:0] rd_in;
    input [4:0] rt_in;
    input [5:0] alu_op;
    input [31:0] imm;
    input [31:0] read_data_2;
    input [31:0] read_data_1;
    input alu_src;
    input alu_sl;
    output [4:0] rd_out;
    output [31:0] alu_input_1;
    output [31:0] alu_input_2;
    output [4:0] alu_control;
 
    Mux3To1 #(.n(5)) read_mux(.out(rd_out), .inA(rt_in), .inB(rd_in), .inC(5'b11111), .sel(reg_dst));

    ALUController alu_controller(.ALUOp(alu_op), .FunctField(imm[5:0]), .ALUControl(alu_control));

    Mux2To1 #(.n(32)) alu_input_2_mux(.out(alu_input_2), .inA(read_data_2), .inB(imm), .sel(alu_src));

    Mux2To1 #(.n(32)) alu_input_1_mux(.out(alu_input_1), .inA(read_data_1), .inB(read_data_2), .sel(alu_sl));

endmodule