`timescale 1ns/1ps

module ALUController(ALUOp, FunctField, ALUControl);
    input [5:0] FunctField;
    input [5:0] ALUOp;
    output reg [4:0] ALUControl;
    always @ (*) begin
        case (ALUOp)
            6'b000000: begin //R Type
                case (FunctField)
                    6'b100000: begin //add
                        ALUControl <= 5'b00000;
                    end
                    6'b100010: begin //sub
                        ALUControl <= 5'b00001;
                    end
                    6'b100100: begin //and
                        ALUControl <= 5'b00010;
                    end
                    6'b100101: begin //OR
                        ALUControl <= 5'b00011;
                    end
                    6'b100111: begin //NOR
                        ALUControl <= 5'b00100;
                    end
                    6'b100110: begin //XOR
                        ALUControl <= 5'b00101;
                    end
                    6'b000010: begin //SRL
                        ALUControl <= 5'b00111;
                    end
                    6'b101010: begin //SLT
                        ALUControl <= 5'b01000;
                    end
                    default: begin //latch error
                        ALUControl <= 5'b11111; //DEBUG ALU SIGNAL
                    end
                endcase
            end
            6'b011100: begin //MUL
                ALUControl <= 5'b01001;
            end
            // I type
            6'b001000: begin //ADDI
                ALUControl <= 5'b10000;
            end
            6'b001100: begin //ANDI
                ALUControl <= 5'b10001;
            end
            6'b001101: begin //ORI
                ALUControl <= 5'b10010;
            end
            6'b001110: begin //XORI
                ALUControl <= 5'b10011;
            end
            //misc
            6'b111110: begin //SLL
                ALUControl <= 5'b00110;
            end
            6'b001010: begin //SLTI
                ALUControl <= 5'b11100;
            end
            default: begin
                ALUControl <= 5'b11111; //DEBUG ALU SIGNAL
            end
        endcase
    end
        
endmodule