`timescale 1ns/1ps

module FUMEM1(rs, rt, rd_mem2_wb, reg_write_mem2_wb, forward_a, forward_b);

    input [4:0] rs;
    input [4:0] rt;
    input [4:0] rd_mem2_wb;
    input reg_write_mem2_wb;
    output reg forward_a;
    output reg forward_b;

    always @(*) begin

        forward_a <= 0;
        forward_b <= 0;
       
       // address
        if ((reg_write_mem2_wb) && (rd_mem2_wb != 0) && (rd_mem2_wb == rs)) begin
            forward_a <= 2'b1;
        end
        
       // write data
        if ((reg_write_mem2_wb) && (rd_mem2_wb != 0) && (rd_mem2_wb == rt)) begin
            forward_b <= 2'b1;
        end
    
    end
endmodule