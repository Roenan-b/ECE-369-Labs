`timescale 1ns/1ps

module BranchALU(branch_op, branch, A, B, pc_src);

    input [2:0] branch_op;
    input branch;
    input signed [31:0] A;
    input signed [31:0] B;
    output reg pc_src;

    always @ (*) begin
        pc_src <= 0;
        if (branch) begin
            case (branch_op) 
                3'b001:  begin //bgez
                    pc_src <= (A >= 0) ? 1 : 0;
                end
                3'b010: begin //blez
                    pc_src <= (A <= 0) ? 1 : 0;
                end
                3'b011: begin //beq
                    pc_src <= (A == B) ? 1 : 0;
                end
                3'b100: begin //bne
                    pc_src <= (A != B) ? 1 : 0;
                end
                3'b101: begin //bgtz
                    pc_src <= (A > 0) ? 1 : 0;
                end
                3'b110: begin //bltz
                    pc_src <= (A < 0) ? 1 : 0;
                end
            endcase
        end
    end
endmodule