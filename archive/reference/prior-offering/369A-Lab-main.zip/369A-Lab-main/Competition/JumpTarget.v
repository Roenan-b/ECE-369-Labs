`timescale 1ns / 1ps

module JumpTarget(pc_input, jaddress, pc_output);

    input [3:0] pc_input;
    input [25:0] jaddress;
    output [31:0] pc_output;
    
    assign pc_output = {pc_input, jaddress, 2'b00};
endmodule
