`timescale 1ns / 1ps

module Mux3To1 #(parameter n = 32) (out, inA, inB, inC, sel);

    output reg [n-1:0] out;
    
    input [n-1:0] inA;
    input [n-1:0] inB;
    input [n-1:0] inC;
    input [1:0] sel;
 
    always@(*)begin
        if (sel == 2) begin
            out <= inC;
        end
        else if (sel == 1) begin
            out <= inB;
        end
        else if (sel == 0) begin
            out <= inA;
        end
        else begin
            out <= inA;
        end
    end
endmodule
