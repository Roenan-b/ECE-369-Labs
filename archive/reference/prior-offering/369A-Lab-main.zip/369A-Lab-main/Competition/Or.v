`timescale 1ns / 1ps

module Or(inA, inB, out);
    input inA, inB;
    output out;
    
    assign out = (inA | inB);
endmodule