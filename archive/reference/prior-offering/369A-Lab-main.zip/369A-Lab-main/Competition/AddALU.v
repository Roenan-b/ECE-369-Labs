`timescale 1ns/1ps

module AddALU(inA, inB, Add_out);

    input [31:0] inA;
    input [31:0] inB;
    output [31:0]Add_out;
    
    assign Add_out = inA + inB;
endmodule