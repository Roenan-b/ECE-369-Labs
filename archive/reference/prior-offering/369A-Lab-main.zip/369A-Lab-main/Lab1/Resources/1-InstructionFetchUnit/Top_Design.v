`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/04/2024 02:01:23 PM
// Design Name: 
// Module Name: Top_Design
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Top_Design(Clk, Reset, out7, en_out);
    input Clk;
    input Reset;
    output [6:0] out7;
    output [7:0] en_out;
    wire ClkOut;
    wire [15:0] Instruction;
    wire [15:0] PCResult;
        ClkDiv m1 (Clk, 0, ClkOut);
        InstructionFetchUnit m2(Instruction, PCResult, Reset, ClkOut);
        //Instruction, PCResult, Reset, Clk
        Two4DigitDisplay m3(Clk, Instruction, PCResult, out7, en_out);
        //Clk, NumberA, NumberB, out7, en_out
endmodule
