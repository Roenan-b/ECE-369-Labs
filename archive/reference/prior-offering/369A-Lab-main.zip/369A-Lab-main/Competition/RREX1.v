`timescale 1ns/1ps

module RREX1 (clk, reset, pc_in, rd_in, rt_in, rs_in, imm_in, read_data_1_in, read_data_2_in, alu_src_in, alu_op_in, reg_dst_in, mem_write_in, mem_read_in, dm_op_in, mem_to_reg_in, reg_write_in, alu_sl_in, pc_out, rd_out, rt_out, rs_out, imm_out, read_data_1_out, read_data_2_out, alu_src_out, alu_op_out, reg_dst_out, mem_write_out, mem_read_out, dm_op_out, mem_to_reg_out, reg_write_out, alu_sl_out);

    input clk;
    input reset;
    input [31:0] pc_in;
    input [4:0] rd_in;
    input [4:0] rt_in;
    input [4:0] rs_in;
    input [31:0] imm_in;
    input [31:0] read_data_1_in;
    input [31:0] read_data_2_in;
    input alu_src_in;
    input [5:0] alu_op_in;
    input [1:0] reg_dst_in;
    input mem_write_in;
    input mem_read_in;
    input [1:0] dm_op_in;
    input [1:0] mem_to_reg_in;
    input reg_write_in;
    input alu_sl_in;
    output reg [31:0] pc_out;
    output reg [4:0] rd_out;
    output reg [4:0] rt_out;
    output reg [4:0] rs_out;
    output reg [31:0] imm_out;
    output reg [31:0] read_data_1_out;
    output reg [31:0] read_data_2_out;
    output reg alu_src_out;
    output reg [5:0] alu_op_out;
    output reg [1:0] reg_dst_out;
    output reg mem_write_out;
    output reg mem_read_out;
    output reg [1:0] dm_op_out;
    output reg [1:0] mem_to_reg_out;
    output reg reg_write_out;
    output reg alu_sl_out;

    always @(posedge clk) begin
        if (reset) begin
            pc_out <= 31'b0;
            rd_out <= 5'b0;
            rt_out <= 5'b0;
            rs_out <= 5'b0;
            imm_out <= 32'b0;
            read_data_1_out <= 32'b0;
            read_data_2_out <= 32'b0;
            alu_src_out <= 0;
            alu_op_out <= 6'b0;
            reg_dst_out <= 0;
            mem_write_out <= 0;
            mem_read_out <= 0;
            dm_op_out <= 2'b0;
            mem_to_reg_out <= 2'b00;
            reg_write_out <= 0;
            alu_sl_out <= 0;
        end else begin
            pc_out <= pc_in;
            rd_out <= rd_in;
            rt_out <= rt_in;
            rs_out <= rs_in;
            imm_out <= imm_in;
            read_data_1_out <= read_data_1_in;
            read_data_2_out <= read_data_2_in;
            alu_src_out <= alu_src_in;
            alu_op_out <= alu_op_in;
            reg_dst_out <= reg_dst_in;
            mem_write_out <= mem_write_in;
            mem_read_out <= mem_read_in;
            dm_op_out <= dm_op_in;
            mem_to_reg_out <= mem_to_reg_in;
            reg_write_out <= reg_write_in;
            alu_sl_out <= alu_sl_in;
        end
    end

endmodule
