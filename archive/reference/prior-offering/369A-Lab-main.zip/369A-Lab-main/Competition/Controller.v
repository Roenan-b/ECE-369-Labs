`timescale 1ns / 1ps

module Controller(rst, instruction, branch_in, JrOp, ALUSrc, ALUOp, RegDst, RegWrite, Branch, MemWrite, MemRead, MemtoReg, DMOp, JumpOp, ALUSl, BranchOp, if_flush, id_flush);

    input rst;
    input branch_in;
    input [31:0] instruction;
    reg [5:0] opcode, funct;
    reg [4:0] shamt, rt;
    reg [15:0] immediate;
    reg [25:0] jaddress;
    output reg JrOp;
    output reg ALUSrc;
    output reg MemWrite;
    output reg MemRead;
    output reg [1:0] MemtoReg, RegDst;
    output reg RegWrite;
    output reg [5:0] ALUOp;
    output reg [1:0] DMOp;
    output reg Branch;
    output reg JumpOp;
    output reg ALUSl;
    output reg if_flush;
    output reg id_flush;
    output reg [2:0] BranchOp;
    
    // 3 bit types identify first
    always @ (*) begin

        opcode <= instruction[31:26];

        if (branch_in) begin
            if_flush <= 1;
            id_flush <= 1;
        end
        else begin
            if_flush <= 0;
            id_flush <= 0;
        end

        if (rst) begin
            RegDst <= 00;
            JrOp <= 0;
            ALUSrc <= 0;
            MemtoReg <= 0;
            RegWrite <= 0;
            MemWrite <= 0;
            MemRead <= 0;
            Branch <= 0;
            ALUOp <= 6'b000000;
            DMOp <= 2'b11;
            JumpOp <= 0;
            ALUSl <= 0;
            BranchOp <= 3'b000;
        end
        else if (instruction == 32'b000000000000000000000000) begin
            RegDst <= 00;
            JrOp <= 0;
            ALUSrc <= 0;
            MemtoReg <= 0;
            RegWrite <= 0;
            MemWrite <= 0;
            MemRead <= 0;
            Branch <= 0;
            ALUOp <= 6'b000000;
            DMOp <= 2'b11;
            JumpOp <= 0;
            ALUSl <= 0;
            BranchOp <= 3'b000;
        end
        else begin

            if (opcode == 6'b000010 | opcode == 6'b000011) begin //j type
                jaddress <= instruction[25:0];
                if_flush <= 1;
            end
            else if (opcode == 6'b000000) begin //R type
                funct <= instruction[5:0];
                shamt <= instruction[10:6];
                rt <= instruction[20:16];
            end
            else if (opcode == 6'b000001) begin // Branch
                rt <= instruction[20:16];
            end
            else begin
                if (opcode != 6'b000000) begin //I type
                    immediate <= instruction[15:0];
                    rt <= instruction[20:16];
                end
            end
            case (opcode)
                /*
                add - 0x00 0x20 // 
                addi - 0x08 // 
                sub - 0x00 0x22 // 
                mul - 0x00 0x18 // 
                lw - 0x23 // 
                sw - 0x2B // 
                sb - 0x28 // 
                lh - 0x21 // 
                lb - 0x20 // 
                sh - 0x29 // 
                bgez - 0x01 // rt = 1
                beq - 0x04 // 
                bne - 0x05 // 
                bgtz - 0x07 // 
                blez -  0x06 // 
                bltz - 0x01 // rt = 0
                j - 0x02 // 
                jr - 0x00 0x08 // 
                jal - 0x03 // 
                and - 0x00 0x20 // 
                andi - 0x0C // 
                or - 0x00 0x25 // 
                nor - 0x00 0x27 // 
                xor - 0x00 0x26 // 
                ori - 0x0D //
                xori - 0x0E //
                sll - 0x00 0x00 // 
                srl - 0x00 0x02 // 
                slt - 0x00 0x2A // 
                slti - 0x0A // 
                */
                6'b000000: begin //R Type
                    funct <= instruction[5:0];
                    case (funct)
                        6'b100000: begin //add
                            RegDst <= 01;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 1;
                            RegWrite <= 1;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b000000;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b000;
                        end
                        6'b100010: begin //sub
                            RegDst <= 01;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 1;
                            RegWrite <= 1;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b000000;
                            DMOp <= 2'b11;
                            JumpOp <= 2'b00;
                            ALUSl <= 0;
                            BranchOp <= 3'b000;
                        end
                        6'b100100: begin //and
                            RegDst <= 01;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 1;
                            RegWrite <= 1;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b000000;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b000;
                        end
                        6'b100101: begin //OR
                            RegDst <= 01;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 1;
                            RegWrite <= 1;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b000000;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b000;
                        end
                        6'b100111: begin //NOR
                            RegDst <= 01;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 1;
                            RegWrite <= 1;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b000000;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b000;
                        end
                        6'b100110: begin //XOR
                            RegDst <= 01;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 1;
                            RegWrite <= 1;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b000000;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b000;
                        end
                        6'b000000: begin //SLL
                            RegDst <= 01;
                            JrOp <= 0;
                            ALUSrc <= 1;
                            MemtoReg <= 1;
                            RegWrite <= 1;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b111110;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 1;
                            BranchOp <= 3'b000;
                        end
                        6'b000010: begin //SRL
                            RegDst <= 01;
                            JrOp <= 0;
                            ALUSrc <= 1;
                            MemtoReg <= 1;
                            RegWrite <= 1;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b000000;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 1;
                            BranchOp <= 3'b000;
                        end
                        6'b101010: begin //SLT
                            RegDst <= 01;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 1;
                            RegWrite <= 1;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b000000;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b000;
                        end
                        6'b001000: begin //JR
                            RegDst <= 00;
                            JrOp <= 1;
                            ALUSrc <= 0;
                            MemtoReg <= 0;
                            RegWrite <= 0;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b111111;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            if_flush <= 1;
                            BranchOp <= 3'b000;
                        end
                        default: begin //latch error
                            RegDst <= 00;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 0;
                            RegWrite <= 0;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b111111;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b000;
                        end
                    endcase
                end
                6'b011100: begin // MUL
                            RegDst <= 01;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 1;
                            RegWrite <= 1;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b011100;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b000;
                        end
                6'b000001: begin // BGEZ or BLTZ
                    case(rt)
                        5'b00000: begin //BLTZ
                            RegDst <= 00;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 1;
                            RegWrite <= 0;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 1;
                            ALUOp <= 6'b111111;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b110;
                        end
                        5'b00001: begin // BGEZ
                            RegDst <= 00;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 1;
                            RegWrite <= 0;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 1;
                            ALUOp <= 6'b111111;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b001;
                        end
                        default: begin //Latch error
                            RegDst <= 00;
                            JrOp <= 0;
                            ALUSrc <= 0;
                            MemtoReg <= 0;
                            RegWrite <= 0;
                            MemWrite <= 0;
                            MemRead <= 0;
                            Branch <= 0;
                            ALUOp <= 6'b111111;
                            DMOp <= 2'b11;
                            JumpOp <= 0;
                            ALUSl <= 0;
                            BranchOp <= 3'b000;
                        end
                    endcase
                end
                // I-Type Instructions
                6'b001000: begin //ADDI
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 1;
                    RegWrite <= 1;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b001000;   
                    DMOp <= 2'b11;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b001100: begin //ANDI
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 1;
                    RegWrite <= 1;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b001100;  
                    DMOp <= 2'b11; 
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b001101: begin //ORI
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 1;
                    RegWrite <= 1;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b001101;
                    DMOp <= 2'b11; 
                    JumpOp <= 0;   
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b001110: begin //XORI
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 1;
                    RegWrite <= 1;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b001110;  
                    DMOp <= 2'b11;
                    JumpOp <= 0;   
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b001010: begin //SLTI
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 1;
                    RegWrite <= 1;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b001010;  
                    DMOp <= 2'b11;
                    JumpOp <= 0; 
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b100011: begin //LW
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 0;
                    RegWrite <= 1;
                    MemWrite <= 0;
                    MemRead <= 1;
                    Branch <= 0;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b11;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b101011: begin //SW
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 0;
                    RegWrite <= 0;
                    MemWrite <= 1;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b11;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b100001: begin //LH
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 0;
                    RegWrite <= 1;
                    MemWrite <= 0;
                    MemRead <= 1;
                    Branch <= 0;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b01;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b100000: begin //LB
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 0;
                    RegWrite <= 1;
                    MemWrite <= 0;
                    MemRead <= 1;
                    Branch <= 0;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b00;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b101001: begin //SH
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 0;
                    RegWrite <= 0;
                    MemWrite <= 1;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b01;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b101000: begin //SB
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 1;
                    MemtoReg <= 0;
                    RegWrite <= 0;
                    MemWrite <= 1;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b00;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                // Branch Type Instructions
                6'b000100: begin //BEQ
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 0;
                    MemtoReg <= 1;
                    RegWrite <= 0;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 1;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b11;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b011;
                end
                6'b000101: begin //BNE
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 0;
                    MemtoReg <= 1;
                    RegWrite <= 0;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 1;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b11;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b100;
                end
                6'b000111: begin //BGTZ
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 0;
                    MemtoReg <= 1;
                    RegWrite <= 0;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 1;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b11;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b101;
                end
                6'b000110: begin //BLEZ
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 0;
                    MemtoReg <= 1;
                    RegWrite <= 0;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 1;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b11;
                    JumpOp <= 0;
                    ALUSl <= 0;
                    BranchOp <= 3'b010;
                end
                // J Type Instructions
                6'b000010: begin // J j type
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 0;
                    MemtoReg <= 0;
                    RegWrite <= 0;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b11;
                    JumpOp <= 1;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                6'b000011: begin // JAL j type
                    RegDst <= 10;
                    JrOp <= 0;
                    ALUSrc <= 0;
                    MemtoReg <= 2;
                    RegWrite <= 1;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b111111; 
                    DMOp <= 2'b11;
                    JumpOp <= 1;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
                default: begin //Latch Error
                    RegDst <= 00;
                    JrOp <= 0;
                    ALUSrc <= 0;
                    MemtoReg <= 0;
                    RegWrite <= 0;
                    MemWrite <= 0;
                    MemRead <= 0;
                    Branch <= 0;
                    ALUOp <= 6'b111111;
                    DMOp <= 2'b11;
                    JumpOp <= 2'b0;
                    ALUSl <= 0;
                    BranchOp <= 3'b000;
                end
            endcase
        end
    end
        
endmodule