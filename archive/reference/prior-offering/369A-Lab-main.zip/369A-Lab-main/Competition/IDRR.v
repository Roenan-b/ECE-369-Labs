`timescale 1ns/1ps

module IDRR (clk, reset, instruction_in, pc_in, jr_op_in, alu_src_in, alu_op_in, reg_dst_in, mem_write_in, mem_read_in, dm_op_in, mem_to_reg_in, reg_write_in, alu_sl_in, branch_in, branch_op_in, instruction_out, pc_out, jr_op_out, alu_src_out, alu_op_out, reg_dst_out, mem_write_out, mem_read_out, dm_op_out, mem_to_reg_out, reg_write_out, alu_sl_out, branch_out, branch_op_out);

    input clk;
    input reset;
    input [25:0] instruction_in;
    input [31:0] pc_in;
    input jr_op_in;
    input alu_src_in;
    input [5:0] alu_op_in;
    input [1:0] reg_dst_in;
    input mem_write_in;
    input mem_read_in;
    input [1:0] dm_op_in;
    input [1:0] mem_to_reg_in;
    input reg_write_in;
    input alu_sl_in;
    input branch_in;
    input [2:0] branch_op_in;
    output reg [25:0] instruction_out;
    output reg [31:0] pc_out;
    output reg jr_op_out;
    output reg alu_src_out;
    output reg [5:0] alu_op_out;
    output reg [1:0] reg_dst_out;
    output reg mem_write_out;
    output reg mem_read_out;
    output reg [1:0] dm_op_out;
    output reg [1:0] mem_to_reg_out;
    output reg reg_write_out;
    output reg alu_sl_out;
    output reg branch_out;
    output reg [2:0] branch_op_out;

    always @(posedge clk) begin
        if (reset) begin
            instruction_out <= 26'b0;
            pc_out <= 32'b0;
            jr_op_out <= 0;
            alu_src_out <= 0;
            alu_op_out <= 6'b0;
            reg_dst_out <= 0;
            mem_write_out <= 0;
            mem_read_out <= 0;
            dm_op_out <= 2'b0;
            mem_to_reg_out <= 2'b0;
            reg_write_out <= 0;
            alu_sl_out <= 0;
            branch_out <= 0;
            branch_op_out <= 3'b0;
        end else begin
            instruction_out <= instruction_in;
            pc_out <= pc_in;
            jr_op_out <= jr_op_in;
            alu_src_out <= alu_src_in;
            alu_op_out <= alu_op_in;
            reg_dst_out <= reg_dst_in;
            mem_write_out <= mem_write_in;
            mem_read_out <= mem_read_in;
            dm_op_out <= dm_op_in;
            mem_to_reg_out <= mem_to_reg_in;
            reg_write_out <= reg_write_in;
            alu_sl_out <= alu_sl_in;
            branch_out <= branch_in;
            branch_op_out <= branch_op_in;
        end
    end

endmodule
