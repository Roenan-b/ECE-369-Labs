def ScanFile(filename):
    try:
        with open(filename, "r") as f:
            for line in f:
                print(line, end="")
    except FileNotFoundError:
        print("File not found")
    except PermissionError:
        print("Permission denied")
    except Exception as e:
        print("Error:", e)
    finally:
        print("File scan completed")


def ArrayToFile(filename, array):
    try:
        with open(filename, "w") as f:
            for item in array:
                f.write(str(item) + "\n")
    except Exception as e:
        print("Error:", e)
    finally:
        print("Array written to file")
