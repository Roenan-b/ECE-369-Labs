`timescale 1ns / 1ps

module PC(Address, PCResult, Reset, Clk, PCWrite);

	input [31:0] Address;
	input Reset, Clk, PCWrite;

	output reg [31:0] PCResult;
	assign pc_curr = PCResult;

	always @(negedge Clk)
	begin
		if (Reset)
			PCResult <= 32'h00000000;
		else if (PCWrite)
			PCResult <= Address;
	end


endmodule