`timescale 1ns/1ps

module MEM1(rs, rt, imm, read_data_1, read_data_2, rd_mem2_wb, reg_write_mem2_wb, data_wb, address, write_data);

    input [4:0] rs;
    input [4:0] rt;
    input [31:0] imm;
    input [31:0] read_data_1;
    input [31:0] read_data_2;
    input [4:0] rd_mem2_wb;
    input reg_write_mem2_wb;
    input [31:0] data_wb;
    output [11:0] address;
    output [31:0] write_data;

    wire [31:0] address_add_input, address_temp;
    wire forward_a, forward_b;

    FUMEM1 forwarding_unit(.rs(rs), .rt(rt), .rd_mem2_wb(rd_mem2_wb), .reg_write_mem2_wb(reg_write_mem2_wb), .forward_a(forward_a), .forward_b(forward_b));

    Mux2To1 #(.n(32)) write_data_mux(.out(write_data), .inA(read_data_2), .inB(data_wb), .sel(forward_b));
    Mux2To1 #(.n(32)) address_mux(.out(address_add_input), .inA(read_data_1), .inB(data_wb), .sel(forward_a));

    AddALU address_add(.inA(address_add_input), .inB(imm), .Add_out(address_temp));
    assign address = address_temp[11:0];

endmodule
