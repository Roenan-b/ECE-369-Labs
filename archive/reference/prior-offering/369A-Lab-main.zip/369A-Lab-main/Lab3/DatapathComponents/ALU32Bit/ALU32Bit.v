`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// ECE369 - Computer Architecture
// 
// Module - ALU32Bit.v
// Description - 32-Bit wide arithmetic logic unit (ALU).
//
// INPUTS:-
// ALUControl: N-Bit input control bits to select an ALU operation.
// A: 32-Bit input port A.
// B: 32-Bit input port B.
//
// OUTPUTS:-
// ALUResult: 32-Bit ALU result output.
// ZERO: 1-Bit output flag. 
//
// FUNCTIONALITY:-
// Design a 32-Bit ALU, so that it supports all arithmetic operations 
// needed by the MIPS instructions given in Labs5-8.docx document. 
//   The 'ALUResult' will output the corresponding result of the operation 
//   based on the 32-Bit inputs, 'A', and 'B'. 
//   The 'Zero' flag is high when 'ALUResult' is '0'. 
//   The 'ALUControl' signal should determine the function of the ALU 
//   You need to determine the bitwidth of the ALUControl signal based on the number of 
//   operations needed to support. 
////////////////////////////////////////////////////////////////////////////////

module ALU32Bit(ALUControl, A, B, ALUResult, Zero);

	input [4:0] ALUControl; // control bits for ALU operation
                                // you need to adjust the bitwidth as needed
	input [31:0] A, B;	    // inputs

	output reg [31:0] ALUResult;	// answer
	output Zero;	    // Zero=1 if ALUResult == 0

    assign Zero = (ALUResult == 0);
        
    /* Please fill in the implementation here... */
    always @ (*) begin
        case (ALUControl)
            5'b00000: begin //add
                ALUResult = A + B;
            end
            5'b00001: begin //sub
                ALUResult = A - B;
            end
            5'b00010: begin //and
                ALUResult = A & B;
            end
            5'b00011: begin //or
                ALUResult = A | B;
            end
            5'b00100: begin //nor
                ALUResult = ~(A|B);
            end
            5'b00101: begin //xor
                ALUResult = A ^ B;
            end
            5'b00110: begin //sll
                ALUResult = A << B;
            end
            5'b00111: begin //srl
                ALUResult = A >> B;
            end
            5'b01000: begin //slt
                ALUResult = (A < B) ? 1 : 0;
            end
            5'b01001: begin //mul
                ALUResult = A * B;
            end
//            5'b01010: begin //jr
//                ALUResult = 
//            end
//            5'b01011: begin //bgez or blez
                
//            end
            5'b01100: begin //beq
                ALUResult = (A == B) ? 1 : 0;
            end
            5'b01101: begin //bne
                ALUResult = (A != B) ? 1 : 0;
            end
            5'b01110: begin //bgtz
                ALUResult = (A > 0) ? 1 : 0;
            end
            5'b01111: begin //blez
                ALUResult = (A <= 0) ? 1 : 0;
            end
            5'b10000: begin //addi
                ALUResult = A + B;
            end
            5'b10001: begin //andi
                ALUResult = A & B;
            end
            5'b10010: begin //ori
                ALUResult = A | B;
            end
            5'b10011: begin //xori
                ALUResult = A ^ B;
            end
            5'b10100: begin //lw
                ALUResult = A + B;
            end
            5'b10101: begin //sw
                ALUResult = A + B;
            end
            5'b10110: begin //lh
                ALUResult = A + B;
            end
            5'b10111: begin //lb
                ALUResult = A + B;
            end
            5'b11000: begin //sh
                ALUResult = A + B;
            end
            5'b11001: begin //sb
                ALUResult = A + B;
            end
//            5'b11010: begin //j
                
//            end
//            5'b11011: begin //jal
//                ALUResult = A;
//            end
            default: begin
                ALUResult = 0;
            end
            endcase
    end
endmodule

