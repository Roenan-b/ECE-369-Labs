`timescale 1ns/1ps

module IFID(clk, if_id_write, if_flush, instruction_in, pc_in, instruction_out, pc_out);

    input clk;
    input if_id_write;
    input if_flush;
    input [31:0] instruction_in;
    input [31:0] pc_in;
    output reg [31:0] instruction_out;
    output reg [31:0] pc_out;

    always @(posedge clk) begin

        pc_out <= pc_in;

        if (if_flush) begin
            instruction_out <= 32'b0;
        end
        else if (if_id_write) begin
            instruction_out <= instruction_in;
        end
            
    end
    
endmodule    
