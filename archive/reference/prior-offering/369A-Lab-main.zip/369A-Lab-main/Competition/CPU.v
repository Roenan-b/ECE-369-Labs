`timescale 1ns/1ps
// Members: Nick, Darryl, Cieran
// Percentage: 33, 33, 33

module CPU(clk, reset, instruction, pc, write_data, write_register);

    input clk, reset;
    output wire [4:0] write_register;
    output wire [31:0] write_data, instruction, pc;

    // direct connect wires
    wire pc_src, pc_write, if_id_write, if_flush, jump_op;
    wire [31:0] jump_target, branch_target;

    // if wires
    // No distinct output wires

    // if/id wires
    wire [31:0] instruction_if_id, pc_if_id;

    // id wires
    wire jr_op_id, alu_src_id, mem_write_id, mem_read_id, reg_write_id, alu_sl_id, branch_id;
    wire [1:0] reg_dst_id, dm_op_id, mem_to_reg_id;
    wire [2:0] branch_op_id;
    wire [5:0] alu_op_id;

    // id/rr wires
    wire jr_op_id_rr, alu_src_id_rr, mem_write_id_rr, mem_read_id_rr, reg_write_id_rr, alu_sl_id_rr, branch_id_rr;
    wire [1:0] reg_dst_id_rr, dm_op_id_rr, mem_to_reg_id_rr;
    wire [2:0] branch_op_id_rr;
    wire [5:0] alu_op_id_rr;
    wire [25:0] instruction_id_rr;
    wire [31:0] pc_id_rr;

    // rr wires
    wire [4:0] rs_rr, rt_rr, rd_rr;
    wire [31:0] imm_rr, read_data_1_rr, read_data_2_rr;

    // rr/ex1 wires
    wire alu_src_rr_ex1, mem_read_rr_ex1, mem_write_rr_ex1, reg_write_rr_ex1, alu_sl_rr_ex1;
    wire [1:0] reg_dst_rr_ex1, dm_op_rr_ex1, mem_to_reg_rr_ex1;
    wire [4:0] rs_rr_ex1, rt_rr_ex1, rd_rr_ex1;
    wire [5:0] alu_op_rr_ex1;
    wire [31:0] pc_rr_ex1, imm_rr_ex1, read_data_1_rr_ex1, read_data_2_rr_ex1;

    // ex1 wires
    wire [4:0] rd_ex1, alu_control_ex1;
    wire [31:0] alu_input_1_ex1, alu_input_2_ex1;

    // ex1/ex2 wires
    wire mem_write_ex1_ex2, mem_read_ex1_ex2, reg_write_ex1_ex2;
    wire [1:0] dm_op_ex1_ex2, mem_to_reg_ex1_ex2;
    wire [4:0] rs_ex1_ex2, rt_ex1_ex2, rd_ex1_ex2, alu_control_ex1_ex2;
    wire [31:0] pc_ex1_ex2, imm_ex1_ex2, read_data_1_ex1_ex2, read_data_2_ex1_ex2, alu_input_1_ex1_ex2, alu_input_2_ex1_ex2;

    // ex2 wires
    wire [31:0] alu_output_ex2;

    // ex2/mem1 wires
    wire mem_write_ex2_mem1, mem_read_ex2_mem1, reg_write_ex2_mem1;
    wire [1:0] dm_op_ex2_mem1, mem_to_reg_ex2_mem1;
    wire [4:0] rs_ex2_mem1, rt_ex2_mem1, rd_ex2_mem1;
    wire [31:0] pc_ex2_mem1, imm_ex2_mem1, read_data_1_ex2_mem1, read_data_2_ex2_mem1, alu_output_ex2_mem1;

    // mem1 wires
    wire [11:0] address_mem1;
    wire [31:0] write_data_mem1;

    // mem1/mem2 wires
    wire mem_write_mem1_mem2, mem_read_mem1_mem2, reg_write_mem1_mem2;
    wire [1:0] dm_op_mem1_mem2, mem_to_reg_mem1_mem2;
    wire [4:0] rt_mem1_mem2, rd_mem1_mem2;
    wire [11:0] address_mem1_mem2;
    wire [31:0] pc_mem1_mem2, alu_output_mem1_mem2, write_data_mem1_mem2;

    // mem2 wires
    wire [31:0] read_data_mem2;

    // mem2/wb wires
    wire reg_write_mem2_wb;
    wire [1:0] mem_to_reg_mem2_wb;
    wire [4:0] rd_mem2_wb;
    wire [31:0] pc_mem2_wb, alu_output_mem2_wb, read_data_mem2_wb;

    // wb wires
    // No distinct output wires

    IF instruction_fetch(.clk(clk), .reset(reset), .pc_in(pc), .pc_src(pc_src), .pc_write(pc_write), .jump_op(jump_op), .jr_op(jr_op_id_rr), .jump_target(jump_target), .branch_target(branch_target), .jump_register(read_data_1_rr), .instruction_out(instruction), .pc_out(pc));
    IFID if_id(.clk(clk), .if_id_write(if_id_write), .if_flush(if_flush), .instruction_in(instruction), .pc_in(pc), .instruction_out(instruction_if_id), .pc_out(pc_if_id));
    ID instruction_decode(.reset(reset), .instruction(instruction_if_id), .pc_in(pc_if_id[31:28]), .rt_id_rr(rt_rr), .rt_rr_ex1(rt_rr_ex1), .rd_id_rr(rd_rr), .mem_read_id_rr(mem_read_id_rr), .mem_read_rr_ex1(mem_read_rr_ex1), .pc_src(pc_src), .jr_op(jr_op_id), .alu_src(alu_src_id), .alu_op(alu_op_id), .reg_dst(reg_dst_id), .mem_write(mem_write_id), .mem_read(mem_read_id), .dm_op(dm_op_id), .mem_to_reg(mem_to_reg_id), .reg_write(reg_write_id), .jump_target(jump_target), .jump_op(jump_op), .alu_sl(alu_sl_id), .if_flush(if_flush), .pc_write(pc_write), .if_id_write(if_id_write), .branch(branch_id), .branch_op(branch_op_id));
    IDRR id_rr(.clk(clk), .reset(reset), .instruction_in(instruction_if_id[25:0]), .pc_in(pc_if_id), .jr_op_in(jr_op_id), .alu_src_in(alu_src_id), .alu_op_in(alu_op_id), .reg_dst_in(reg_dst_id), .mem_write_in(mem_write_id), .mem_read_in(mem_read_id), .dm_op_in(dm_op_id), .mem_to_reg_in(mem_to_reg_id), .reg_write_in(reg_write_id), .alu_sl_in(alu_sl_id), .branch_in(branch_id), .branch_op_in(branch_op_id), .instruction_out(instruction_id_rr), .pc_out(pc_id_rr), .jr_op_out(jr_op_id_rr), .alu_src_out(alu_src_id_rr), .alu_op_out(alu_op_id_rr), .reg_dst_out(reg_dst_id_rr), .mem_write_out(mem_write_id_rr), .mem_read_out(mem_read_id_rr), .dm_op_out(dm_op_id_rr), .mem_to_reg_out(mem_to_reg_id_rr), .reg_write_out(reg_write_id_rr), .alu_sl_out(alu_sl_id_rr), .branch_out(branch_id_rr), .branch_op_out(branch_op_id_rr));
    RR read_register(.clk(clk), .instruction(instruction_id_rr), .write_data(write_data), .write_register(write_register), .reg_write_in(reg_write_mem2_wb), .pc_in(pc_id_rr), .rd_ex2_mem1(rd_ex2_mem1), .reg_write_ex2_mem1(reg_write_ex2_mem1), .data_ex2_mem1(alu_output_ex2_mem1), .branch(branch_id_rr), .branch_op(branch_op_id_rr), .rd_out(rd_rr), .rt_out(rt_rr), .rs_out(rs_rr), .imm_out(imm_rr), .read_data_2(read_data_2_rr), .read_data_1(read_data_1_rr), .branch_target(branch_target), .pc_src(pc_src));
    RREX1 ex_rr(.clk(clk), .reset(reset), .pc_in(pc_id_rr), .rd_in(rd_rr), .rt_in(rt_rr), .rs_in(rs_rr), .imm_in(imm_rr), .read_data_1_in(read_data_1_rr), .read_data_2_in(read_data_2_rr), .alu_src_in(alu_src_id_rr), .alu_op_in(alu_op_id_rr), .reg_dst_in(reg_dst_id_rr), .mem_write_in(mem_write_id_rr), .mem_read_in(mem_read_id_rr), .dm_op_in(dm_op_id_rr), .mem_to_reg_in(mem_to_reg_id_rr), .reg_write_in(reg_write_id_rr), .alu_sl_in(alu_sl_id_rr), .pc_out(pc_rr_ex1), .rd_out(rd_rr_ex1), .rt_out(rt_rr_ex1), .rs_out(rs_rr_ex1), .imm_out(imm_rr_ex1), .read_data_1_out(read_data_1_rr_ex1), .read_data_2_out(read_data_2_rr_ex1), .alu_src_out(alu_src_rr_ex1), .alu_op_out(alu_op_rr_ex1), .reg_dst_out(reg_dst_rr_ex1), .mem_write_out(mem_write_rr_ex1), .mem_read_out(mem_read_rr_ex1), .dm_op_out(dm_op_rr_ex1), .mem_to_reg_out(mem_to_reg_rr_ex1), .reg_write_out(reg_write_rr_ex1), .alu_sl_out(alu_sl_rr_ex1));
    EX1 execute_control(.reg_dst(reg_dst_rr_ex1), .rd_in(rd_rr_ex1), .rt_in(rt_rr_ex1), .alu_op(alu_op_rr_ex1), .imm(imm_rr_ex1), .read_data_2(read_data_2_rr_ex1), .read_data_1(read_data_1_rr_ex1), .alu_src(alu_src_rr_ex1), .alu_sl(alu_sl_rr_ex1), .rd_out(rd_ex1), .alu_input_1(alu_input_1_ex1), .alu_input_2(alu_input_2_ex1), .alu_control(alu_control_ex1));
    EX1EX2 ex1_ex2(.clk(clk), .reset(reset), .pc_in(pc_rr_ex1), .rd_in(rd_ex1), .rt_in(rt_rr_ex1), .rs_in(rs_rr_ex1), .imm_in(imm_rr_ex1), .read_data_1_in(read_data_1_rr_ex1), .read_data_2_in(read_data_2_rr_ex1), .alu_input_1_in(alu_input_1_ex1), .alu_input_2_in(alu_input_2_ex1), .alu_control_in(alu_control_ex1), .mem_write_in(mem_write_rr_ex1), .mem_read_in(mem_read_rr_ex1), .dm_op_in(dm_op_rr_ex1), .mem_to_reg_in(mem_to_reg_rr_ex1), .reg_write_in(reg_write_rr_ex1), .pc_out(pc_ex1_ex2), .rd_out(rd_ex1_ex2), .rt_out(rt_ex1_ex2), .rs_out(rs_ex1_ex2), .imm_out(imm_ex1_ex2), .read_data_1_out(read_data_1_ex1_ex2), .read_data_2_out(read_data_2_ex1_ex2), .alu_input_1_out(alu_input_1_ex1_ex2), .alu_input_2_out(alu_input_2_ex1_ex2), .alu_control_out(alu_control_ex1_ex2), .mem_write_out(mem_write_ex1_ex2), .mem_read_out(mem_read_ex1_ex2), .dm_op_out(dm_op_ex1_ex2), .mem_to_reg_out(mem_to_reg_ex1_ex2), .reg_write_out(reg_write_ex1_ex2));
    EX2 execute_alu(.rt(rt_ex1_ex2), .rs(rs_ex1_ex2), .alu_input_1(alu_input_1_ex1_ex2), .alu_input_2(alu_input_2_ex1_ex2), .alu_control(alu_control_ex1_ex2), .rd_ex2_mem1(rd_ex2_mem1), .rd_mem2_wb(write_register), .data_ex2_mem1(alu_output_ex2_mem1), .data_mem2_wb(write_data), .reg_write_ex2_mem1(reg_write_ex2_mem1), .reg_write_mem2_wb(reg_write_mem2_wb), .alu_output(alu_output_ex2));
    EX2MEM1 ex2_mem1(.clk(clk), .reset(reset), .pc_in(pc_ex1_ex2), .rd_in(rd_ex1_ex2), .rt_in(rt_ex1_ex2), .rs_in(rs_ex1_ex2), .imm_in(imm_ex1_ex2), .read_data_1_in(read_data_1_ex1_ex2), .read_data_2_in(read_data_2_ex1_ex2), .alu_output_in(alu_output_ex2), .mem_write_in(mem_write_ex1_ex2), .mem_read_in(mem_read_ex1_ex2), .dm_op_in(dm_op_ex1_ex2), .mem_to_reg_in(mem_to_reg_ex1_ex2), .reg_write_in(reg_write_ex1_ex2), .pc_out(pc_ex2_mem1), .rd_out(rd_ex2_mem1), .rt_out(rt_ex2_mem1), .rs_out(rs_ex2_mem1), .imm_out(imm_ex2_mem1), .read_data_1_out(read_data_1_ex2_mem1), .read_data_2_out(read_data_2_ex2_mem1), .alu_output_out(alu_output_ex2_mem1), .mem_write_out(mem_write_ex2_mem1), .mem_read_out(mem_read_ex2_mem1), .dm_op_out(dm_op_ex2_mem1), .mem_to_reg_out(mem_to_reg_ex2_mem1), .reg_write_out(reg_write_ex2_mem1));
    MEM1 memory_address_calculation(.rs(rs_ex2_mem1), .rt(rt_ex2_mem1), .imm(imm_ex2_mem1), .read_data_1(read_data_1_ex2_mem1), .read_data_2(read_data_1_ex2_mem1), .rd_mem2_wb(write_register), .reg_write_mem2_wb(reg_write_mem2_wb), .data_wb(write_data), .address(address_mem1), .write_data(write_data_mem1));
    MEM1MEM2 mem1_mem2(.clk(clk), .reset(reset), .pc_in(pc_ex2_mem1), .rd_in(rd_ex2_mem1), .rt_in(rt_ex2_mem1), .alu_output_in(alu_output_ex2_mem1), .address_in(address_mem1), .write_data_in(write_data_mem1), .mem_write_in(mem_write_ex2_mem1), .mem_read_in(mem_read_ex2_mem1), .dm_op_in(dm_op_ex2_mem1), .mem_to_reg_in(mem_to_reg_ex2_mem1), .reg_write_in(reg_write_ex2_mem1), .pc_out(pc_mem1_mem2), .rd_out(rd_mem1_mem2), .rt_out(rt_mem1_mem2), .alu_output_out(alu_output_mem1_mem2), .address_out(address_mem1_mem2), .write_data_out(write_data_mem1_mem2), .mem_write_out(mem_write_mem1_mem2), .mem_read_out(mem_read_mem1_mem2), .dm_op_out(dm_op_mem1_mem2), .mem_to_reg_out(mem_to_reg_mem1_mem2), .reg_write_out(reg_write_mem1_mem2));
    MEM2 memory_access(.clk(clk), .rt(rt_mem1_mem2), .address(address_mem1_mem2), .write_data(write_data_mem1_mem2), .mem_write(mem_write_mem1_mem2), .mem_read(mem_read_mem1_mem2), .dm_op(dm_op_mem1_mem2), .rd_mem2_wb(write_register), .reg_write_mem2_wb(reg_write_mem2_wb), .data_wb(write_data), .read_data(read_data_mem2));
    MEM2WB mem2_wb(.clk(clk), .reset(reset), .pc_in(pc_mem1_mem2), .rd_in(rd_mem1_mem2), .alu_output_in(alu_output_mem1_mem2), .read_data_in(read_data_mem2),. mem_to_reg_in(mem_to_reg_mem1_mem2), .reg_write_in(reg_write_mem1_mem2), .pc_out(pc_mem2_wb), .rd_out(write_register), .alu_output_out(alu_output_mem2_wb), .read_data_out(read_data_mem2_wb), .mem_to_reg_out(mem_to_reg_mem2_wb), .reg_write_out(reg_write_mem2_wb));
    WB write_back(.pc_in(pc_mem2_wb), .read_data(read_data_mem2_wb), .alu_output(alu_output_mem2_wb), .mem_to_reg(mem_to_reg_mem2_wb), .write_data(write_data));

endmodule