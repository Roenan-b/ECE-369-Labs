`timescale 1ns/1ps

module ID(reset, instruction, pc_in, rt_id_rr, rt_rr_ex1, rd_id_rr, mem_read_id_rr, mem_read_rr_ex1, pc_src, jr_op, alu_src, alu_op, reg_dst, mem_write, mem_read, dm_op, mem_to_reg, reg_write, jump_target, jump_op, alu_sl, if_flush, pc_write, if_id_write, branch, branch_op);

    input reset;
    input [31:0] instruction;
    input [3:0] pc_in;
    input [4:0] rt_id_rr;
    input [4:0] rt_rr_ex1;
    input [4:0] rd_id_rr;
    input mem_read_id_rr;
    input mem_read_rr_ex1;
    input pc_src;
    output jr_op;
    output alu_src;
    output [5:0] alu_op;
    output [1:0] reg_dst;
    output mem_write;
    output mem_read;
    output [1:0] dm_op;
    output [1:0] mem_to_reg;
    output reg_write;
    output [31:0] jump_target;
    output jump_op;
    output alu_sl;
    output if_flush;
    output pc_write;
    output if_id_write;
    output branch;
    output [2:0] branch_op;

    wire [25:0] jump_address = instruction[25:0]; 
    wire id_flush;
    wire control_mux;
    wire flush;
    wire jr_op_mux;
    wire alu_src_mux;
    wire [5:0] alu_op_mux;
    wire [1:0] reg_dst_mux;
    wire mem_write_mux;
    wire mem_read_mux;
    wire [1:0] dm_op_mux;
    wire branch_mux;
    wire [1:0] mem_to_reg_mux;
    wire reg_write_mux;
    wire jump_op_mux;
    wire alu_sl_mux;
    wire [31:0] shift_offset;
    wire [2:0] branch_op_mux;

    Controller control(.rst(reset), .instruction(instruction), .branch_in(pc_src), .JrOp(jr_op), .ALUSrc(alu_src_mux), .ALUOp(alu_op_mux), .RegDst(reg_dst_mux), .RegWrite(reg_write_mux), .Branch(branch_mux), .MemWrite(mem_write_mux), .MemRead(mem_read_mux), .MemtoReg(mem_to_reg_mux), .DMOp(dm_op_mux), .JumpOp(jump_op_mux), .ALUSl(alu_sl_mux), .if_flush(if_flush), .id_flush(id_flush), .BranchOp(branch_op_mux));
    
    HDU hazard_detection(.op_code_id(instruction[31:26]), .rs_id(instruction[25:21]), .rt_id(instruction[20:16]), .rt_id_rr(rt_id_rr), .rt_rr_ex1(rt_rr_ex1), .rd_id_rr(rd_id_rr), .mem_read_id_rr(mem_read_id_rr), .mem_read_rr_ex1(mem_read_rr_ex1), .if_id_write(if_id_write), .pc_write(pc_write), .control_mux(control_mux));

    Or flush_or(.inA(control_mux), .inB(id_flush), .out(flush));

    JumpTarget jump(.pc_input(pc_in), .jaddress(jump_address), .pc_output(jump_target));
    
    // Flush muxes
    Mux2To1 #(.n(1)) alu_src_flush_mux(.out(jr_op), .inA(jr_op_mux), .inB(1'b0), .sel(flush));
    Mux2To1 #(.n(1)) alu_src_flush_mux(.out(alu_src), .inA(alu_src_mux), .inB(1'b0), .sel(flush));
    Mux2To1 #(.n(6)) alu_op_flush_mux(.out(alu_op), .inA(alu_op_mux), .inB(6'b0), .sel(flush));
    Mux2To1 #(.n(2)) reg_dst_flush_mux(.out(reg_dst), .inA(reg_dst_mux), .inB(2'b0), .sel(flush));
    Mux2To1 #(.n(1)) reg_write_flush_mux(.out(reg_write), .inA(reg_write_mux), .inB(1'b0), .sel(flush));
    Mux2To1 #(.n(1)) branch_flush_mux(.out(branch), .inA(branch_mux), .inB(1'b0), .sel(flush));
    Mux2To1 #(.n(1)) mem_write_flush_mux(.out(mem_write), .inA(mem_write_mux), .inB(1'b0), .sel(flush));
    Mux2To1 #(.n(1)) mem_read_flush_mux(.out(mem_read), .inA(mem_read_mux), .inB(1'b0), .sel(flush));
    Mux2To1 #(.n(2)) mem_to_reg_flush_mux(.out(mem_to_reg), .inA(mem_to_reg_mux), .inB(2'b0), .sel(flush));
    Mux2To1 #(.n(2)) dm_op_flush_mux(.out(dm_op), .inA(dm_op_mux), .inB(2'b0), .sel(flush));
    Mux2To1 #(.n(1)) jump_op_flush_mux(.out(jump_op), .inA(jump_op_mux), .inB(1'b0), .sel(flush));
    Mux2To1 #(.n(1)) alu_sl_flush_mux(.out(alu_sl), .inA(alu_sl_mux), .inB(1'b0), .sel(flush));
    Mux2To1 #(.n(3)) branch_op_flush_mux(.out(branch_op), .inA(branch_op_mux), .inB(3'b0), .sel(flush));

endmodule